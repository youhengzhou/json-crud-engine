# JSON Engine

JSON Database Engine for Python

Written for personal use in projects

Documentation WIP